package com.example.sandbox;

import io.restassured.response.Response;

import java.util.Map;

import static io.restassured.RestAssured.given;

public class Common extends Endpoints {
    public static String ID;

    //----------------------------------GET----------------------------------
    public Response getPetUrl(String endpoint, Map<String, String> headers) {
        return given()
                .relaxedHTTPSValidation()
                .and()
                .headers(headers)
                .log().everything()
                .when()
                .get(baseUrl + endpoint + ID)
                .then()
                .log()
                .all()
                .extract().response();
    }

    //----------------------------------DELETE----------------------------------
    public Response deleteUrl(String endpoint, Map<String, String> headers) {
        return given()
                .relaxedHTTPSValidation()
                .headers(headers)
                .and()
                .log().everything()
                .when()
                .delete(baseUrl + endpoint + ID)
                .then()
                .log()
                .all()
                .extract().response();

    }

    //----------------------------------POST----------------------------------
    public Response postUrl(String endpoint, Map<String, String> body, Map<String, String> headers) {
        return given()
                .relaxedHTTPSValidation()
                .contentType("application/json; charset=UTF-8")
                .body(body)
                .headers(headers)
                .and()
                .log().everything()
                .when()
                .post(baseUrl + endpoint)
                .then()
                .log()
                .all()
                .extract().response();

    }
}

