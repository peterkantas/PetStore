package com.example.sandbox;

public class Endpoints {

    static final String baseUrl = "https://petstore.swagger.io/v2";

    //-------------------------pet-------------------------
    public static final String newPet = "/pet";
    public static final String petById = "/pet/";

}
