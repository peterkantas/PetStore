package com.example.sandbox.util.constans;

public class Tags {
    public static final String SMOKE = "smoke";
    public static final String REGRESSION = "regression";
    public static final String ADD = "add";
    public static final String DELETE = "delete";
    }
