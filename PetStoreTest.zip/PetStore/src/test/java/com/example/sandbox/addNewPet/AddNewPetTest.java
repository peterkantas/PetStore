package com.example.sandbox.addNewPet;

import com.example.sandbox.Common;
import com.example.sandbox.checkPetById.CheckPetById;
import com.example.sandbox.util.JsonUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Map;
import java.util.TreeMap;

import static com.example.sandbox.util.constans.Tags.ADD;
import static com.example.sandbox.util.constans.Tags.REGRESSION;

public class AddNewPetTest extends Common {
    @Test(enabled = true, groups = {REGRESSION,ADD}, description = "description")
    public void addNewPet() throws JsonProcessingException {
        Map<String, String> queryParams = new TreeMap<>();
        queryParams.put("status", "available");
        Map<String, String> headers = new TreeMap<>();
        headers.put("Mandatoyheader", "BFG");
        Response response = postUrl(newPet, queryParams, headers);
        Assert.assertEquals(response.getStatusCode(), 200, "Invalid response code");
        JsonUtils ju = new JsonUtils();
        JsonNode resp = ju.castStringToJsonNode(response.body().prettyPrint());
        ID = resp.get("id").asText();
        Assert.assertNotNull(ID);
        CheckPetById chpbi = new CheckPetById();
        chpbi.checkPetById(200);
    }

}
