package com.example.sandbox.checkPetById;

import com.example.sandbox.Common;
import com.example.sandbox.util.JsonUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import io.restassured.response.Response;
import org.testng.Assert;

import java.util.Map;
import java.util.TreeMap;

public class CheckPetById extends Common {

    public static JsonNode checkPetByIdResponse;

    public void checkPetById(int statuscode) throws JsonProcessingException {
        Map<String, String> queryParams = new TreeMap<>();
        queryParams.put("status","available");
        Map<String, String> headers = new TreeMap<>();
        headers.put("Mandatoyheader","BFG");
        Response response = getPetUrl(petById,headers);
        Assert.assertEquals(response.getStatusCode(),statuscode,"Invalid response code");
        JsonUtils ju = new JsonUtils();
        checkPetByIdResponse = ju.castStringToJsonNode(response.body().prettyPrint());

    }
}
