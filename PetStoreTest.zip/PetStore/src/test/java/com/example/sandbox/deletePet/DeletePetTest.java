package com.example.sandbox.deletePet;

import com.example.sandbox.Common;
import com.example.sandbox.addNewPet.AddNewPetTest;
import com.example.sandbox.checkPetById.CheckPetById;
import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Map;
import java.util.TreeMap;

import static com.example.sandbox.checkPetById.CheckPetById.checkPetByIdResponse;
import static com.example.sandbox.util.constans.Tags.*;

public class DeletePetTest extends Common {
    @Test(enabled = true,groups = {SMOKE,REGRESSION,DELETE},description ="description")
    public void deletePet() throws JsonProcessingException {
        AddNewPetTest anpt = new AddNewPetTest();
        anpt.addNewPet();
        Map<String, String> queryParams = new TreeMap<>();
        queryParams.put("status","available");
        Map<String, String> headers = new TreeMap<>();
        headers.put("Mandatoyheader","BFG");
        Response response = deleteUrl(petById,headers);
        Assert.assertEquals(response.getStatusCode(),200,"Invalid response code");
        Assert.assertNotNull(ID);
        CheckPetById chpbi = new CheckPetById();
        chpbi.checkPetById(404);
        Assert.assertEquals(checkPetByIdResponse.get("message").asText(),"Pet not found");

    }
}
